import React from 'react';
import {
  StyleSheet,
  Text,
  TextInput,
  View,
  TouchableOpacity,
  StatusBar,
  KeyboardAvoidingView,
  SafeAreaView,
  Platform,
} from 'react-native';

const Login = (props) => {
  const {navigation} = props;
  return (
    <>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : null}
        style={{flex: 1}}>
        <SafeAreaView style={styles.container}>
          <StatusBar barStyle={'light-content'} backgroundColor="#212529" />
          <View style={styles.back} />
          <View style={styles.front}>
            <View style={styles.heading}>
              <TouchableOpacity style={styles.titleContainer}>
                <Text style={styles.title}>Sign In</Text>
                <View style={styles.active} />
              </TouchableOpacity>
            </View>
            <View style={{marginVertical: 20}}>
              <TextInput style={styles.input} placeholder="Enter Email" />
              <TextInput style={styles.input} placeholder="Enter Password" />
            </View>
            <TouchableOpacity
              style={styles.loginButton}
              onPress={() => navigation.navigate('DashboardTabs')}>
              <Text style={{color: '#fff'}}>Sign In </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.forgetButton}
              onPress={() => navigation.navigate('ForgetPassword')}>
              <Text> Forget Password</Text>
            </TouchableOpacity>
          </View>
        </SafeAreaView>
      </KeyboardAvoidingView>

      {console.log(props)}
    </>
  );
};

export default Login;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // justifyContent: 'center',
  },
  input: {
    backgroundColor: '#fff',
    margin: 10,
    paddingHorizontal: 10,
    borderWidth: 1,
    borderRadius: 10,
    borderColor: '#d3d3d3',
  },
  loginButton: {
    backgroundColor: '#212529',
    paddingVertical: 10,
    paddingHorizontal: 30,
    alignSelf: 'center',
    marginTop: 10,
    borderRadius: 10,
    width: '80%',
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
  },
  back: {
    backgroundColor: '#212529',
    height: 300,
  },
  front: {
    backgroundColor: '#fff',
    height: '70%',
    width: '80%',
    position: 'absolute',
    alignSelf: 'center',
    marginHorizontal: 100,
    marginTop: 150,
    borderRadius: 15,
  },
  heading: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    height: 80,
    borderBottomWidth: 1,
    borderBottomColor: '#d3d3d3',
  },
  title: {
    fontSize: 20,
  },
  titleContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  active: {
    backgroundColor: '#000',
    height: 5,
    width: 50,
    margin: 10,
    borderRadius: 50,
  },
  forgetButton: {
    marginTop: 10,
    alignSelf: 'center',
  },
});
