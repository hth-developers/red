import React from 'react';
import {StyleSheet, Text, View} from 'react-native';

const Delivery = () => {
  return (
    <View>
      <Text> Delivery</Text>
    </View>
  );
};

export default Delivery;

const styles = StyleSheet.create({});
