import React from 'react';
import {StyleSheet, Text, View} from 'react-native';

const Inward = () => {
  return (
    <View>
      <Text>Inward</Text>
    </View>
  );
};

export default Inward;

const styles = StyleSheet.create({});
