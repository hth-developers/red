import React from 'react';
import {StyleSheet, Text, View} from 'react-native';

const Dispatch = () => {
  return (
    <View>
      <Text>Dispatch</Text>
    </View>
  );
};

export default Dispatch;

const styles = StyleSheet.create({});
